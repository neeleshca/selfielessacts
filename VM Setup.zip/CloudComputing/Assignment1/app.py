from flask import Flask, render_template, url_for
from inspect import getsourcefile
from os.path import abspath

import os
app = Flask(__name__)

print("LOLOL",abspath(getsourcefile(lambda:0)))
print("FIL",abspath(getsourcefile(lambda:0)).rsplit('/',1)[0])

PATH = abspath(getsourcefile(lambda:0)).rsplit('/',1)[0]
# @app.route("/")
# def hello_world():
#     return render_template("home.html")

@app.route("/")
def images():
   # print("hello")
   # print("12 4",os.listdir('static'))
    
    #images = os.listdir('static/Categories/Category_0')
    images = os.listdir(PATH+'/static/Categories/Category_0')
    print(images)    
    for i in images:
	print(i)
    images = ['Categories/Category_0/' + file for file in images]
    print(images)
    return render_template('images.html',images=images)
    
if __name__ == "__main__":
    app.run()
